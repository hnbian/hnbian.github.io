#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-$ROOT/.venv/bin/python}"

if [[ ! -x "$PYTHON_BIN" ]]; then
  echo "Python interpreter not found: $PYTHON_BIN" >&2
  exit 1
fi

"$PYTHON_BIN" -m ruff check "$ROOT"
"$PYTHON_BIN" -m ruff format --check "$ROOT"
(cd "$ROOT" && "$PYTHON_BIN" -m pyright)
"$PYTHON_BIN" -m compileall -q "$ROOT"
(cd "$ROOT" && ./test_all.sh)
"$PYTHON_BIN" -m pip check

echo "All Harness quality checks passed."
