#!/usr/bin/env python3
"""Resumable in-process approval with LangGraph and an OpenSandbox policy."""

from __future__ import annotations

import argparse
import json
import math
from typing import Any, NotRequired, Required, TypedDict

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt
from opensandbox import SandboxSync
from opensandbox.models.sandboxes import NetworkPolicy


class ApprovalState(TypedDict, total=False):
    purchase_id: Required[str]
    amount: Required[float]
    approved: NotRequired[bool]
    status: NotRequired[str]
    decision: NotRequired[str]


def request_approval(state: ApprovalState) -> dict[str, object]:
    purchase_id = state["purchase_id"]
    amount = state["amount"]
    if not isinstance(purchase_id, str) or not purchase_id.strip():
        raise ValueError("purchase_id is required")
    if (
        isinstance(amount, bool)
        or not isinstance(amount, (int, float))
        or not math.isfinite(amount)
        or amount <= 0
    ):
        raise ValueError("amount must be positive")
    decision = interrupt(
        {
            "kind": "purchase_approval",
            "purchase_id": purchase_id,
            "amount": amount,
            "allowed_decisions": ["approve", "reject"],
        }
    )
    if not isinstance(decision, dict):
        raise ValueError("resume payload must be an object")
    decision_name = decision.get("decision")
    if decision_name not in {"approve", "reject"}:
        raise ValueError("decision must be approve or reject")
    approved = decision_name == "approve"
    return {
        "approved": approved,
        "decision": decision_name,
        "status": "approved" if approved else "rejected",
    }


def build_graph() -> Any:
    builder = StateGraph(ApprovalState)
    builder.add_node("approval", request_approval)
    builder.add_edge(START, "approval")
    builder.add_edge("approval", END)
    return builder.compile(checkpointer=InMemorySaver())


def approval_demo(decision: str) -> dict[str, object]:
    graph = build_graph()
    config = {"configurable": {"thread_id": "purchase-demo-001"}}
    paused = graph.invoke({"purchase_id": "PO-001", "amount": 1200.0}, config)
    if not paused.get("__interrupt__"):
        raise AssertionError("graph did not pause")
    resumed = graph.invoke(Command(resume={"decision": decision}), config)
    return {
        "interrupt": paused["__interrupt__"][0].value,
        "status": resumed["status"],
        "approved": resumed["approved"],
    }


def sandbox_policy() -> NetworkPolicy:
    # Deny-by-default: production may add narrowly scoped egress rules.
    return NetworkPolicy(defaultAction="deny", egress=[])


def create_external_sandbox(image: str) -> dict[str, object]:
    sandbox = SandboxSync.create(
        image=image,
        network_policy=sandbox_policy(),
        resource={"cpu": "1", "memory": "512Mi"},
        metadata={"purpose": "harness-course-demo"},
    )
    try:
        info = sandbox.get_info()
        return {"sandbox_id": info.id, "healthy": sandbox.is_healthy()}
    finally:
        sandbox.kill()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    approved = approval_demo("approve")
    require(approved["status"] == "approved", "approve path failed")
    rejected = approval_demo("reject")
    require(rejected["status"] == "rejected", "reject path failed")
    policy = sandbox_policy().model_dump(by_alias=True)
    require(policy["defaultAction"] == "deny", "network policy is not deny by default")
    try:
        approval_demo("invalid")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid resume decision was accepted")
    graph = build_graph()
    try:
        graph.invoke(
            {"purchase_id": "PO-INVALID", "amount": -1.0},
            {"configurable": {"thread_id": "invalid-amount"}},
        )
    except ValueError:
        pass
    else:
        raise AssertionError("negative approval amount was accepted")
    try:
        graph.invoke(
            {"purchase_id": "PO-BOOL", "amount": True},
            {"configurable": {"thread_id": "invalid-bool-amount"}},
        )
    except ValueError:
        pass
    else:
        raise AssertionError("boolean approval amount was accepted")
    for thread_id, invalid_state in (
        ("invalid-empty-purchase", {"purchase_id": "   ", "amount": 1.0}),
        ("invalid-infinite-amount", {"purchase_id": "PO-INF", "amount": float("inf")}),
    ):
        try:
            graph.invoke(
                invalid_state,
                {"configurable": {"thread_id": thread_id}},
            )
        except ValueError:
            pass
        else:
            raise AssertionError(f"invalid approval state was accepted: {thread_id}")
    print("p07 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--decision", choices=["approve", "reject"], default="approve")
    parser.add_argument("--create-sandbox", action="store_true")
    parser.add_argument("--image", default="python:3.12-slim")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    result = (
        create_external_sandbox(args.image) if args.create_sandbox else approval_demo(args.decision)
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
