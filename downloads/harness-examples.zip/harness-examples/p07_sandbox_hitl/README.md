# p07 — Sandbox and human-in-the-loop

## 功能

默认路径使用真实 LangGraph `interrupt()`、`InMemorySaver` 和 `Command(resume=...)`。第一次调用把状态保存在进程内并暂停；调用方第二次以相同 `thread_id` 调用图并恢复。输入状态把采购单和金额声明为必需字段，并在运行时拒绝空采购单和非正金额；恢复载荷只接受 approve/reject。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认 HITL 演示不需要外部服务
- `--create-sandbox` 需要 OpenSandbox Server、API key 和连接域名

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py --decision approve
python main.py --decision reject
./test.sh
```

## 示例输出

```json
{
  "interrupt": {
    "kind": "purchase_approval",
    "purchase_id": "PO-001",
    "amount": 1200.0
  },
  "status": "approved",
  "approved": true
}
```

OpenSandbox 外部路径会创建 deny-by-default 的网络策略，并保证在 `finally` 中销毁实例：

```bash
cp .env.example .env
set -a; source .env; set +a
python main.py --create-sandbox --image python:3.12-slim
```

这条命令需要已部署的 OpenSandbox Server 与正确连接配置，默认测试不会连接它。生产检查点应替换为数据库实现；普通进程内存不能支持跨进程恢复。
