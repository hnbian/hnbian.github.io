from __future__ import annotations

import time
import unittest

from p08_fastapi_sse_mcp.main import RunStore
from p09_async_subagents.main import TaskManager
from p10_procurement_harness.main import ProcurementHarness


class RuntimeRegressionTests(unittest.TestCase):
    def test_resume_is_idempotent_and_terminal(self) -> None:
        store = RunStore()
        body = {
            "decision": "approve",
            "expected_version": 1,
            "idempotency_key": "approval-key-001",
            "approver": "reviewer-42",
        }
        first = store.resume("demo", **body)
        self.assertEqual(first, store.resume("demo", **body))
        with self.assertRaises(RuntimeError):
            store.resume(
                "demo",
                decision="reject",
                expected_version=2,
                idempotency_key="rejection-key-001",
                approver="reviewer-42",
            )

    def test_resume_rejects_conflicting_idempotency_key_and_preserves_event_order(
        self,
    ) -> None:
        store = RunStore()
        self.assertEqual([1, 2], [event["id"] for event in store.snapshot("demo").events])
        store.resume(
            "demo",
            decision="approve",
            expected_version=1,
            idempotency_key="approval-key-001",
            approver="reviewer-42",
        )
        self.assertEqual(
            [1, 2, 3],
            [event["id"] for event in store.snapshot("demo").events],
        )
        with self.assertRaises(ValueError):
            store.resume(
                "demo",
                decision="reject",
                expected_version=1,
                idempotency_key="approval-key-001",
                approver="reviewer-42",
            )

    def test_async_update_and_cancel_change_execution(self) -> None:
        manager = TaskManager(max_workers=1)
        try:
            updated_id = manager.start("before", steps=20)
            manager.update(updated_id, "after")
            updated = manager.wait(updated_id)
            self.assertEqual(updated.result, "completed: after")

            cancelled_id = manager.start("cancel-me", steps=200)
            deadline = time.monotonic() + 1
            while manager.check(cancelled_id).status == "queued" and time.monotonic() < deadline:
                time.sleep(0.005)
            manager.cancel(cancelled_id)
            self.assertEqual(manager.wait(cancelled_id).status, "cancelled")
        finally:
            manager.close()

    def test_procurement_no_shortage_selects_no_supplier(self) -> None:
        result = ProcurementHarness().run(
            "M8-BOLT",
            5,
            minimum_payment_days=30,
            approved=None,
        )
        self.assertEqual(result["shortage"], 0)
        self.assertIsNone(result["selected_quote"])

    def test_procurement_rejects_negative_demand(self) -> None:
        with self.assertRaises(ValueError):
            ProcurementHarness().run(
                "M8-BOLT",
                -1,
                minimum_payment_days=30,
                approved=None,
            )
        with self.assertRaises(ValueError):
            ProcurementHarness().run(
                "M8-BOLT",
                True,
                minimum_payment_days=30,
                approved=None,
            )

    def test_procurement_rejects_duplicate_run_id(self) -> None:
        harness = ProcurementHarness()
        with self.assertRaises(ValueError):
            harness.start(
                "M8-BOLT",
                500,
                minimum_payment_days=30,
                run_id="   ",
            )
        harness.start(
            "M8-BOLT",
            500,
            minimum_payment_days=30,
            run_id="regression-duplicate",
        )
        with self.assertRaises(ValueError):
            harness.start(
                "M8-BOLT",
                500,
                minimum_payment_days=30,
                run_id="regression-duplicate",
            )


if __name__ == "__main__":
    unittest.main()
