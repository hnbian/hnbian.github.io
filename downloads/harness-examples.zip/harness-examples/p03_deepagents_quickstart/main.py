#!/usr/bin/env python3
"""A real Deep Agents graph with deterministic and optional live model modes."""

from __future__ import annotations

import argparse
import os
import re
from importlib.metadata import version
from typing import Any

from deepagents import create_deep_agent
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage
from langchain_core.tools import tool


@tool
def multiply(a: int, b: int) -> int:
    """Multiply two integers."""
    return a * b


class ToolAwareFakeModel(FakeMessagesListChatModel):
    """LangChain's fake model plus the tool-binding contract required by agents."""

    def bind_tools(
        self,
        tools: Any,
        *,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> ToolAwareFakeModel:
        return self


def deterministic_agent(a: int = 6, b: int = 7):
    model = ToolAwareFakeModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "multiply",
                        "args": {"a": a, "b": b},
                        "id": "call_multiply_1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content=f"{a} × {b} = {a * b}"),
        ]
    )
    return create_deep_agent(
        model=model,
        tools=[multiply],
        system_prompt="Use tools for arithmetic and answer concisely.",
        name="quickstart_harness",
    )


def live_agent():
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY is required for --live")
    from langchain_openai import ChatOpenAI

    model = ChatOpenAI(model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"), temperature=0)
    return create_deep_agent(model=model, tools=[multiply], name="quickstart_live")


def run(agent: Any, question: str) -> str:
    result = agent.invoke({"messages": [{"role": "user", "content": question}]})
    return str(result["messages"][-1].content)


def run_deterministic(question: str) -> str:
    match = re.fullmatch(r"\s*(?:请计算|计算)?\s*(-?\d+)\s*[×*]\s*(-?\d+)\s*", question)
    if match is None:
        raise ValueError("deterministic mode accepts integer multiplication such as '6 × 7'")
    a, b = (int(value) for value in match.groups())
    return run(deterministic_agent(a, b), question)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    require(version("deepagents") == "0.6.12", "unexpected Deep Agents version")
    answer = run_deterministic("请计算 6 × 7")
    require(answer == "6 × 7 = 42", "tool calling result mismatch")
    require(run_deterministic("3 * 9") == "3 × 9 = 27", "question was ignored")
    try:
        run_deterministic("解释 Harness")
    except ValueError:
        pass
    else:
        raise AssertionError("unsupported deterministic prompt was silently ignored")
    print("p03 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("question", nargs="?", default="请计算 6 × 7")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    print(run(live_agent(), args.question) if args.live else run_deterministic(args.question))


if __name__ == "__main__":
    main()
