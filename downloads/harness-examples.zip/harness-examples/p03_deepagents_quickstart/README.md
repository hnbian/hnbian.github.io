# p03 — Deep Agents quickstart

## 功能

这里真正调用 `deepagents.create_deep_agent`，让模型产生 `multiply` 工具调用，再由框架执行并把结果送回模型。默认使用支持工具绑定的确定性 LangChain 模型，因此测试不消耗令牌。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认模式不需要模型密钥
- `--live` 需要 OpenAI 兼容 API key

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py
python main.py "3 * 9"
./test.sh
```

## 示例输出

```text
6 × 7 = 42
```

确定性模式支持整数乘法；无法处理的提示会明确报错，不会忽略输入并返回固定答案。真实模型路径：

```bash
cp .env.example .env
set -a; source .env; set +a
python main.py --live "请计算 23 乘以 19"
```

该路径需要有效 `OPENAI_API_KEY`，未配置时会立即失败，不会静默退回模拟结果。
