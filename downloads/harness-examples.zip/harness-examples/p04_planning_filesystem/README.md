# p04 — Planning and filesystem

## 功能

案例展示三个互补机制：

1. 真实 Deep Agents 图调用内置 `write_todos` 和 `write_file`。
2. 本地恢复模型跳过已完成计划项，避免重复副作用。
3. 真实 `CompositeBackend` 把普通工作文件与 `/memories/` 磁盘文件路由到不同根目录。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认确定性模型不需要 API key
- 示例只写入自动清理的临时目录

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py
./test.sh
```

## 示例输出

```json
{
  "backend": {
    "memory": "优先选择账期 30 天以上的供应商"
  },
  "deep_agent": {
    "answer": "采购计划已完成。",
    "todos": [
      {"content": "查询库存", "status": "completed"}
    ]
  }
}
```

`virtual_mode=True` 让绝对虚拟路径被映射到指定根目录；不要在生产中把不受信任路径直接交给宿主文件系统。示例使用临时目录，只证明磁盘路由，不声称跨进程长期持久；跨线程 Store 示例见 `p06_context_memory_skills`。
