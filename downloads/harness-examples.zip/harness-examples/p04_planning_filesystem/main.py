#!/usr/bin/env python3
"""Real Deep Agents planning tools plus resumable local plan execution."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from deepagents import create_deep_agent
from deepagents.backends import CompositeBackend, FilesystemBackend
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage


@dataclass
class Todo:
    content: str
    status: str = "pending"


class ToolAwareFakeModel(FakeMessagesListChatModel):
    """Deterministic model implementing the tool-binding contract."""

    def bind_tools(
        self,
        tools: Any,
        *,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> ToolAwareFakeModel:
        return self


def build_plan() -> list[Todo]:
    return [
        Todo("读取库存与采购需求"),
        Todo("比较供应商报价"),
        Todo("生成待审批采购建议"),
    ]


def execute_plan(
    plan: list[Todo],
    fail_at: int | None = None,
    executed: list[str] | None = None,
) -> list[Todo]:
    """Execute pending items without repeating already completed side effects."""

    for index, todo in enumerate(plan):
        if todo.status == "completed":
            continue
        todo.status = "in_progress"
        if index == fail_at:
            todo.status = "pending"
            break
        if executed is not None:
            executed.append(todo.content)
        todo.status = "completed"
    return plan


def backend_demo(workspace: Path, memory: Path) -> dict[str, str]:
    backend = CompositeBackend(
        default=FilesystemBackend(root_dir=workspace, virtual_mode=True),
        routes={"/memories/": FilesystemBackend(root_dir=memory, virtual_mode=True)},
    )
    plan = build_plan()
    backend.write("/plan.json", json.dumps([asdict(item) for item in plan], ensure_ascii=False))
    backend.write("/memories/preferences.md", "优先选择账期 30 天以上的供应商")
    plan_read = backend.read("/plan.json").file_data
    memory_read = backend.read("/memories/preferences.md").file_data
    if plan_read is None or memory_read is None:
        raise RuntimeError("backend did not return file content")
    return {
        "plan": plan_read["content"],
        "memory": memory_read["content"],
    }


def deep_agent_planning_demo(workspace: Path) -> dict[str, Any]:
    """Run the built-in write_todos and write_file tools in a real graph."""

    model = ToolAwareFakeModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "write_todos",
                        "args": {
                            "todos": [
                                {"content": "查询库存", "status": "in_progress"},
                                {"content": "比较供应商", "status": "pending"},
                                {"content": "生成建议", "status": "pending"},
                            ]
                        },
                        "id": "write_todos_1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "write_file",
                        "args": {
                            "file_path": "/plan-summary.md",
                            "content": "# 采购计划\n\n库存、供应商、采购建议。",
                        },
                        "id": "write_plan_file_1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "write_todos",
                        "args": {
                            "todos": [
                                {"content": "查询库存", "status": "completed"},
                                {"content": "比较供应商", "status": "completed"},
                                {"content": "生成建议", "status": "completed"},
                            ]
                        },
                        "id": "write_todos_2",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content="采购计划已完成。"),
        ]
    )
    agent = create_deep_agent(
        model=model,
        backend=FilesystemBackend(root_dir=workspace, virtual_mode=True),
        name="planning_demo",
    )
    result = agent.invoke({"messages": [{"role": "user", "content": "规划一次采购并保存摘要"}]})
    return {
        "answer": result["messages"][-1].content,
        "todos": result["todos"],
        "summary": (workspace / "plan-summary.md").read_text(encoding="utf-8"),
    }


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    executed: list[str] = []
    plan = execute_plan(build_plan(), fail_at=1, executed=executed)
    require(
        [item.status for item in plan] == ["completed", "pending", "pending"],
        "failure state mismatch",
    )
    execute_plan(plan, executed=executed)
    require(all(item.status == "completed" for item in plan), "resume did not finish")
    require(
        executed.count(plan[0].content) == 1,
        "resume repeated an already completed side effect",
    )
    with TemporaryDirectory() as work, TemporaryDirectory() as memory:
        result = backend_demo(Path(work), Path(memory))
        require("读取库存" in result["plan"], "plan was not stored")
        require("账期 30 天" in result["memory"], "memory route mismatch")
        require((Path(work) / "plan.json").exists(), "workspace file missing")
        require((Path(memory) / "preferences.md").exists(), "memory file missing")
    with TemporaryDirectory() as work:
        agent_result = deep_agent_planning_demo(Path(work))
        require(agent_result["answer"] == "采购计划已完成。", "agent answer mismatch")
        require(
            all(todo["status"] == "completed" for todo in agent_result["todos"]),
            "built-in write_todos state mismatch",
        )
        require("采购计划" in agent_result["summary"], "agent file output missing")
    print("p04 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    with TemporaryDirectory() as work, TemporaryDirectory() as memory:
        output = {
            "backend": backend_demo(Path(work), Path(memory)),
            "deep_agent": deep_agent_planning_demo(Path(work)),
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
