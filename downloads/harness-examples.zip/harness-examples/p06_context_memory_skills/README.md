# p06 — Context, memory and skills

## 功能

案例使用 Deep Agents 0.6.12 的真实 API：

- `skills=["/skills/"]` 初始只注入名称和描述，模型调用 `read_file` 后才看到正文标记。
- `memory=["/memories/preferences.md"]` 从 StoreBackend 加载长期记忆。
- StoreBackend namespace 使用经过校验的认证 `user_id`；同一用户跨 thread 可见，不同用户隔离。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认确定性模型不需要 API key
- Store 与文件系统均为本机临时测试资源

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py
./test.sh
```

## 示例输出

```json
{
  "initial_has_skill_summary": true,
  "initial_has_skill_body": false,
  "expanded_has_skill_body": true,
  "cross_thread_memory_loaded": true,
  "other_user_isolated": true
}
```

`AGENTS.md` 只是官方示例中常见的 Agent 指令文件名，不是长期记忆的强制命名。本例故意使用 `preferences.md`，证明持久性来自 backend、Store 和 namespace，而不是文件名。

字幕中提到的自动下载、创建、测试和分配 Skills 是课程项目扩展。本例验证稳定版内置的读取和渐进披露，不把课程自定义管理器误称为框架自动能力。
