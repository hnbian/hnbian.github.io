#!/usr/bin/env python3
"""Real Deep Agents skills loading and user-scoped cross-thread memory."""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

import yaml
from deepagents import create_deep_agent
from deepagents.backends import (
    CompositeBackend,
    FilesystemBackend,
    StateBackend,
    StoreBackend,
)
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langgraph.store.memory import InMemoryStore
from pydantic import Field

SKILL_BODY_MARKER = "QUALIFIED_QUOTES_ONLY"
SKILL_TEXT = f"""---
name: supplier-comparison
description: Compare qualified supplier quotes for one SKU.
---

# Supplier comparison

1. Reject quotes with non-positive prices.
2. Prefer the lowest price that satisfies the requested payment term.
3. Return the evidence used for the decision.
4. Verification marker: {SKILL_BODY_MARKER}.
"""


@dataclass(frozen=True)
class UserContext:
    user_id: str


class RecordingFakeModel(FakeMessagesListChatModel):
    """Tool-aware fake model that records the exact model context."""

    captured_prompts: list[str] = Field(default_factory=list)

    def bind_tools(
        self,
        tools: Any,
        *,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> RecordingFakeModel:
        return self

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: Any = None,
        **kwargs: Any,
    ):
        self.captured_prompts.append("\n".join(str(message.content) for message in messages))
        return super()._generate(
            messages,
            stop=stop,
            run_manager=run_manager,
            **kwargs,
        )


def validate_user_id(user_id: str) -> str:
    """Reject path-like or ambiguous identities before namespace selection."""

    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", user_id):
        raise ValueError("user_id must be a stable authenticated identifier")
    return user_id


def bootstrap_skills(root: Path) -> Path:
    skill = root / "skills" / "supplier-comparison" / "SKILL.md"
    skill.parent.mkdir(parents=True, exist_ok=True)
    skill.write_text(SKILL_TEXT, encoding="utf-8")
    return skill


def parse_skill(path: Path) -> dict[str, str]:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---\n") or "\n---\n" not in text[4:]:
        raise ValueError("SKILL.md requires YAML frontmatter")
    raw_frontmatter, body = text[4:].split("\n---\n", 1)
    metadata = yaml.safe_load(raw_frontmatter)
    if (
        not isinstance(metadata, dict)
        or not metadata.get("name")
        or not metadata.get("description")
    ):
        raise ValueError("skill name and description are required")
    return {
        "name": str(metadata["name"]),
        "description": str(metadata["description"]),
        "body": body.strip(),
    }


def build_backend(root: Path) -> CompositeBackend:
    return CompositeBackend(
        default=StateBackend(),
        routes={
            "/skills/": FilesystemBackend(
                root_dir=root / "skills",
                virtual_mode=True,
            ),
            "/memories/": StoreBackend(
                namespace=lambda runtime: (validate_user_id(runtime.context.user_id),)
            ),
        },
    )


def run_real_demo(root: Path) -> dict[str, Any]:
    """Prove lazy skill loading and cross-thread, user-scoped memory."""

    skill_path = bootstrap_skills(root)
    parsed = parse_skill(skill_path)
    store = InMemoryStore()
    backend = build_backend(root)

    writer_model = RecordingFakeModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "write_file",
                        "args": {
                            "file_path": "/memories/preferences.md",
                            "content": "language: zh-CN\nminimum_payment_days: 30\n",
                        },
                        "id": "save_memory_1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content="偏好已保存。"),
        ]
    )
    writer = create_deep_agent(
        model=writer_model,
        skills=["/skills/"],
        memory=["/memories/preferences.md"],
        backend=backend,
        context_schema=UserContext,
        store=store,
        name="memory_writer",
    )
    writer.invoke(
        {"messages": [{"role": "user", "content": "记住我的稳定采购偏好"}]},
        context=UserContext("user-42"),
        config={"configurable": {"thread_id": "memory-thread-1"}},
    )

    reader_model = RecordingFakeModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "read_file",
                        "args": {"file_path": ("/skills/supplier-comparison/SKILL.md")},
                        "id": "read_skill_1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content="已按资格、账期和价格比较供应商。"),
        ]
    )
    reader = create_deep_agent(
        model=reader_model,
        skills=["/skills/"],
        memory=["/memories/preferences.md"],
        backend=backend,
        context_schema=UserContext,
        store=store,
        name="memory_reader",
    )
    result = reader.invoke(
        {"messages": [{"role": "user", "content": "比较供应商"}]},
        context=UserContext("user-42"),
        config={"configurable": {"thread_id": "memory-thread-2"}},
    )

    other_user_model = RecordingFakeModel(responses=[AIMessage(content="无已存偏好。")])
    other_user = create_deep_agent(
        model=other_user_model,
        skills=["/skills/"],
        memory=["/memories/preferences.md"],
        backend=backend,
        context_schema=UserContext,
        store=store,
        name="isolated_user_reader",
    )
    other_user.invoke(
        {"messages": [{"role": "user", "content": "读取我的偏好"}]},
        context=UserContext("user-99"),
        config={"configurable": {"thread_id": "memory-thread-3"}},
    )

    initial_prompt = reader_model.captured_prompts[0]
    expanded_prompt = reader_model.captured_prompts[-1]
    other_prompt = other_user_model.captured_prompts[0]
    return {
        "answer": result["messages"][-1].content,
        "skill": {"name": parsed["name"], "description": parsed["description"]},
        "initial_has_skill_summary": parsed["description"] in initial_prompt,
        "initial_has_skill_body": SKILL_BODY_MARKER in initial_prompt,
        "expanded_has_skill_body": SKILL_BODY_MARKER in expanded_prompt,
        "cross_thread_memory_loaded": "minimum_payment_days: 30" in initial_prompt,
        "other_user_isolated": "minimum_payment_days: 30" not in other_prompt,
        "store_namespaces": [list(namespace) for namespace in store.list_namespaces()],
    }


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    with TemporaryDirectory() as temp:
        result = run_real_demo(Path(temp))
        require(result["initial_has_skill_summary"] is True, "skill summary missing")
        require(
            result["initial_has_skill_body"] is False,
            "skill body was eagerly injected",
        )
        require(
            result["expanded_has_skill_body"] is True,
            "skill body was not loaded on demand",
        )
        require(
            result["cross_thread_memory_loaded"] is True,
            "memory did not persist across threads",
        )
        require(result["other_user_isolated"] is True, "user memory leaked")
        require(
            ["user-42"] in result["store_namespaces"],
            "user namespace was not created",
        )
    try:
        validate_user_id("../escape")
    except ValueError:
        pass
    else:
        raise AssertionError("path-like user_id was accepted")
    print("p06 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    with TemporaryDirectory() as temp:
        print(
            json.dumps(
                run_real_demo(Path(temp)),
                ensure_ascii=False,
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
