# p05 — Multi-agent delegation

## 功能

案例包含两层：

1. 业务层使用显式 `Handoff`、类型化 payload 和结构化 `Finding`，并处理负需求、无采购缺口和空报价。
2. 框架层真正调用 Deep Agents 内置 `task` 工具，把任务交给 `inventory-specialist`，主代理只收到子代理最终结果。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认确定性模型不需要 API key 或远程 Agent Server

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py
./test.sh
```

## 示例输出

```json
{
  "business_contract": {
    "sku": "M8-BOLT",
    "shortage": 260
  },
  "deep_agents_task": {
    "answer": "库存子代理已返回 240。",
    "task_results": ["{\"sku\":\"M8-BOLT\",\"available\":240}"]
  }
}
```

默认使用确定性 LangChain 模型，因此真实框架路径不消耗令牌。测试同时验证业务契约和 `task` ToolMessage。
