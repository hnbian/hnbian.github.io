#!/usr/bin/env python3
"""Real Deep Agents delegation plus typed, serializable handoff contracts."""

from __future__ import annotations

import argparse
import json
from collections.abc import Callable
from dataclasses import asdict, dataclass
from typing import Any, TypedDict

from deepagents import create_deep_agent
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, ToolMessage


@dataclass(frozen=True)
class Handoff:
    task_id: str
    specialist: str
    objective: str
    inputs: dict[str, object]
    expected_output: str


@dataclass(frozen=True)
class Finding:
    task_id: str
    specialist: str
    payload: InventoryPayload | QuotesPayload


class InventoryPayload(TypedDict):
    sku: str
    available: int


class QuoteItem(TypedDict):
    supplier: str
    sku: str
    unit_price: float


class QuotesPayload(TypedDict):
    quotes: list[QuoteItem]


class ToolAwareFakeModel(FakeMessagesListChatModel):
    """Deterministic model implementing tool binding for parent and subagent."""

    def bind_tools(
        self,
        tools: Any,
        *,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> ToolAwareFakeModel:
        return self


def inventory_specialist(handoff: Handoff) -> Finding:
    stock = {"M8-BOLT": 240}
    sku = str(handoff.inputs["sku"])
    return Finding(
        handoff.task_id, handoff.specialist, {"sku": sku, "available": stock.get(sku, 0)}
    )


def supplier_specialist(handoff: Handoff) -> Finding:
    sku = str(handoff.inputs["sku"])
    quotes: list[QuoteItem] = [
        {"supplier": "华东紧固件", "sku": sku, "unit_price": 0.42},
        {"supplier": "联成工业", "sku": sku, "unit_price": 0.47},
    ]
    return Finding(handoff.task_id, handoff.specialist, {"quotes": quotes})


class Supervisor:
    def __init__(self, specialists: dict[str, Callable[[Handoff], Finding]]):
        self.specialists = specialists

    def delegate(self, handoff: Handoff) -> Finding:
        if handoff.specialist not in self.specialists:
            raise KeyError(f"unknown specialist: {handoff.specialist}")
        # Only the handoff is passed; the specialist never receives supervisor history.
        return self.specialists[handoff.specialist](handoff)

    def procure(self, sku: str, required: int) -> dict[str, object]:
        if required < 0:
            raise ValueError("required must be non-negative")
        base = {"sku": sku}
        stock = self.delegate(
            Handoff("stock-1", "inventory", "查询库存", dict(base), "available count")
        )
        if "available" not in stock.payload:
            raise TypeError("inventory specialist returned an invalid payload")
        shortage = max(0, required - stock.payload["available"])
        if shortage == 0:
            return {"sku": sku, "required": required, "shortage": 0, "recommended": None}

        quotes = self.delegate(Handoff("quote-1", "supplier", "查询报价", dict(base), "quote list"))
        if "quotes" not in quotes.payload:
            raise TypeError("supplier specialist returned an invalid payload")
        candidates = quotes.payload["quotes"]
        if not candidates:
            raise ValueError("supplier specialist returned no quotes")
        best = min(candidates, key=lambda item: item["unit_price"])
        return {"sku": sku, "required": required, "shortage": shortage, "recommended": best}


def real_subagent_demo() -> dict[str, Any]:
    """Invoke Deep Agents' real task tool with an isolated subagent context."""

    specialist_model = ToolAwareFakeModel(
        responses=[AIMessage(content='{"sku":"M8-BOLT","available":240}')]
    )
    supervisor_model = ToolAwareFakeModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "task",
                        "args": {
                            "description": (
                                '查询 M8-BOLT 库存，只返回 JSON：{"sku":"M8-BOLT","available":数量}'
                            ),
                            "subagent_type": "inventory-specialist",
                        },
                        "id": "delegate_inventory_1",
                        "type": "tool_call",
                    }
                ],
            ),
            AIMessage(content="库存子代理已返回 240。"),
        ]
    )
    agent = create_deep_agent(
        model=supervisor_model,
        subagents=[
            {
                "name": "inventory-specialist",
                "description": "查询一个 SKU 的库存并返回最小 JSON。",
                "system_prompt": "你是库存专家，只返回请求的 JSON，不接收主代理完整历史。",
                "model": specialist_model,
                "tools": [],
            }
        ],
        name="procurement_supervisor",
    )
    result = agent.invoke({"messages": [{"role": "user", "content": "请委派库存专家查询 M8-BOLT"}]})
    task_results = [
        message.content
        for message in result["messages"]
        if isinstance(message, ToolMessage) and message.name == "task"
    ]
    return {
        "answer": result["messages"][-1].content,
        "task_results": task_results,
    }


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    supervisor = Supervisor({"inventory": inventory_specialist, "supplier": supplier_specialist})
    result = supervisor.procure("M8-BOLT", 500)
    require(result["shortage"] == 260, "shortage mismatch")
    recommended = result["recommended"]
    if not isinstance(recommended, dict):
        raise AssertionError("recommended quote missing")
    require(recommended.get("supplier") == "华东紧固件", "supplier mismatch")
    no_purchase = supervisor.procure("M8-BOLT", 100)
    require(no_purchase["recommended"] is None, "supplier selected without a shortage")
    try:
        supervisor.procure("M8-BOLT", -1)
    except ValueError:
        pass
    else:
        raise AssertionError("negative demand was accepted")
    contract = Handoff("x", "supplier", "报价", {"sku": "M8-BOLT"}, "quotes")
    require(
        json.loads(json.dumps(asdict(contract), ensure_ascii=False))["task_id"] == "x",
        "handoff is not JSON serializable",
    )
    delegated = real_subagent_demo()
    require(delegated["answer"] == "库存子代理已返回 240。", "supervisor answer mismatch")
    require(
        any('"available":240' in str(item) for item in delegated["task_results"]),
        "real task tool did not return the subagent result",
    )
    print("p05 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    supervisor = Supervisor({"inventory": inventory_specialist, "supplier": supplier_specialist})
    print(
        json.dumps(
            {
                "business_contract": supervisor.procure("M8-BOLT", 500),
                "deep_agents_task": real_subagent_demo(),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
