#!/usr/bin/env python3
"""FastAPI SSE, idempotent resume API, and a mounted FastMCP transport."""

from __future__ import annotations

import argparse
import asyncio
import json
import threading
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Annotated, Any, Literal, cast

import uvicorn
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastmcp import Client, FastMCP
from fastmcp.client.transports import StreamableHttpTransport
from httpx import ASGITransport, AsyncClient
from pydantic import BaseModel, Field


@dataclass
class RunRecord:
    status: str
    version: int
    events: list[dict[str, Any]]
    idempotent_responses: dict[str, dict[str, object]] = field(default_factory=dict)
    idempotent_fingerprints: dict[str, tuple[str, int, str]] = field(default_factory=dict)


class RunStore:
    """Thread-safe state transitions for the in-process teaching service."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._runs: dict[str, RunRecord] = {}
        self.reset()

    def reset(self) -> None:
        with self._lock:
            self._runs = {
                "demo": RunRecord(
                    status="waiting_approval",
                    version=1,
                    events=[
                        {
                            "id": 1,
                            "type": "plan",
                            "data": "采购计划已生成",
                        },
                        {
                            "id": 2,
                            "type": "status",
                            "data": {"status": "waiting_approval", "version": 1},
                        },
                    ],
                )
            }

    def snapshot(self, run_id: str) -> RunRecord:
        with self._lock:
            if run_id not in self._runs:
                raise KeyError(run_id)
            record = self._runs[run_id]
            return RunRecord(
                status=record.status,
                version=record.version,
                events=[dict(event) for event in record.events],
                idempotent_responses={
                    key: dict(value) for key, value in record.idempotent_responses.items()
                },
                idempotent_fingerprints=dict(record.idempotent_fingerprints),
            )

    def resume(
        self,
        run_id: str,
        *,
        decision: str,
        expected_version: int,
        idempotency_key: str,
        approver: str,
    ) -> dict[str, object]:
        with self._lock:
            if run_id not in self._runs:
                raise KeyError(run_id)
            normalized_approver = approver.strip()
            if not normalized_approver:
                raise ValueError("authenticated approver required")
            if not idempotency_key.strip():
                raise ValueError("idempotency key must not be blank")
            record = self._runs[run_id]
            fingerprint = (decision, expected_version, normalized_approver)
            if idempotency_key in record.idempotent_responses:
                if record.idempotent_fingerprints[idempotency_key] != fingerprint:
                    raise ValueError("idempotency key was reused with a different request")
                return dict(record.idempotent_responses[idempotency_key])
            if record.status != "waiting_approval":
                raise RuntimeError(f"run is already {record.status}")
            if expected_version != record.version:
                raise ValueError(
                    f"version conflict: expected {expected_version}, current {record.version}"
                )

            record.status = "completed" if decision == "approve" else "rejected"
            record.version += 1
            event = {
                "id": len(record.events) + 1,
                "type": "decision",
                "data": {
                    "decision": decision,
                    "approver": normalized_approver,
                    "status": record.status,
                    "version": record.version,
                },
            }
            record.events.append(event)
            response = {
                "run_id": run_id,
                "status": record.status,
                "version": record.version,
            }
            record.idempotent_responses[idempotency_key] = response
            record.idempotent_fingerprints[idempotency_key] = fingerprint
            return dict(response)


class ResumeBody(BaseModel):
    decision: Literal["approve", "reject"]
    expected_version: int = Field(ge=1, strict=True)
    idempotency_key: str = Field(
        min_length=8,
        max_length=128,
        pattern=r"^.*\S.*$",
        strict=True,
    )


def encode_sse(event: dict[str, Any]) -> str:
    event_id = int(event["id"])
    event_type = str(event["type"])
    data = json.dumps(event["data"], ensure_ascii=False)
    return f"id: {event_id}\nevent: {event_type}\ndata: {data}\n\n"


mcp = FastMCP("procurement-erp")


def query_inventory_impl(sku: str) -> dict[str, object]:
    """Return current ERP inventory for one SKU."""

    return {"sku": sku, "available": 240 if sku == "M8-BOLT" else 0}


mcp.tool(query_inventory_impl, name="query_inventory")
mcp_asgi = mcp.http_app(path="/", stateless_http=True)

app = FastAPI(title="Harness Runtime API", lifespan=mcp_asgi.lifespan)
app.mount("/mcp", mcp_asgi, name="mcp")
RUN_STORE = RunStore()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/runs/{run_id}/events")
async def events(
    run_id: str,
    request: Request,
    follow: bool = True,
    last_event_id: Annotated[str | None, Header(alias="Last-Event-ID")] = None,
) -> StreamingResponse:
    try:
        snapshot = RUN_STORE.snapshot(run_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="run not found") from None
    try:
        cursor = int(last_event_id) if last_event_id is not None else 0
    except ValueError:
        raise HTTPException(status_code=400, detail="Last-Event-ID must be an integer") from None

    async def stream() -> AsyncIterator[str]:
        yield "retry: 3000\n\n"
        cursor_id = cursor
        current = snapshot
        while True:
            if await request.is_disconnected():
                return
            for event in current.events:
                event_id = int(event["id"])
                if event_id > cursor_id:
                    yield encode_sse(event)
                    cursor_id = event_id
            yield ": heartbeat\n\n"
            if not follow or current.status != "waiting_approval":
                return
            await asyncio.sleep(1)
            current = RUN_STORE.snapshot(run_id)

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/runs/{run_id}/resume")
def resume(
    run_id: str,
    body: ResumeBody,
    approver: Annotated[str | None, Header(alias="X-Approver")] = None,
) -> dict[str, object]:
    if approver is None or not approver.strip():
        raise HTTPException(status_code=401, detail="authenticated approver required")
    try:
        return RUN_STORE.resume(
            run_id,
            decision=body.decision,
            expected_version=body.expected_version,
            idempotency_key=body.idempotency_key,
            approver=approver,
        )
    except KeyError:
        raise HTTPException(status_code=404, detail="run not found") from None
    except (RuntimeError, ValueError) as error:
        raise HTTPException(status_code=409, detail=str(error)) from None


async def verify_mcp_protocol() -> dict[str, Any]:
    """Use FastMCP's real client protocol against the registered server."""

    async with Client(mcp) as client:
        tools = await client.list_tools()
        result = await client.call_tool("query_inventory", {"sku": "M8-BOLT"})
    return {
        "tools": [tool.name for tool in tools],
        "structured_content": result.structured_content,
    }


async def verify_mounted_mcp_transport() -> dict[str, Any]:
    """Call the mounted Streamable HTTP endpoint through the ASGI application."""

    def client_factory(**kwargs: Any) -> AsyncClient:
        return AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
            **kwargs,
        )

    transport = StreamableHttpTransport(
        "http://test/mcp/",
        # FastMCP 3.4.4 passes follow_redirects although the upstream MCP
        # callable protocol has not yet declared that keyword.
        httpx_client_factory=cast(Any, client_factory),
    )
    async with app.router.lifespan_context(app), Client(transport) as client:
        tools = await client.list_tools()
        result = await client.call_tool("query_inventory", {"sku": "M8-BOLT"})
    return {
        "tools": [tool.name for tool in tools],
        "structured_content": result.structured_content,
    }


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


async def verify_http_api() -> None:
    RUN_STORE.reset()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        health_response = await client.get("/health")
        require(health_response.json() == {"status": "ok"}, "health failed")
        response = await client.get("/runs/demo/events", params={"follow": "false"})
        require(
            response.headers["content-type"].startswith("text/event-stream"),
            "SSE content type missing",
        )
        require("id: 1" in response.text, "SSE event id missing")
        require("id: 2" in response.text, "SSE status id missing")
        require("event: plan" in response.text, "SSE plan event missing")
        require("waiting_approval" in response.text, "SSE status missing")
        replay = await client.get(
            "/runs/demo/events",
            params={"follow": "false"},
            headers={"Last-Event-ID": "1"},
        )
        require("event: plan" not in replay.text, "SSE replay ignored cursor")
        require("event: status" in replay.text, "SSE replay lost persisted status")

        body = {
            "decision": "approve",
            "expected_version": 1,
            "idempotency_key": "approve-demo-001",
        }
        unauthenticated = await client.post("/runs/demo/resume", json=body)
        require(
            unauthenticated.status_code == 401,
            "unauthenticated approval was accepted",
        )
        whitespace_approver = await client.post(
            "/runs/demo/resume",
            json=body,
            headers={"X-Approver": "   "},
        )
        require(
            whitespace_approver.status_code == 401,
            "whitespace-only approver was accepted",
        )
        approved = await client.post(
            "/runs/demo/resume",
            json=body,
            headers={"X-Approver": "reviewer-42"},
        )
        require(approved.status_code == 200, "approval failed")
        require(approved.json()["status"] == "completed", "approval status mismatch")
        repeated = await client.post(
            "/runs/demo/resume",
            json=body,
            headers={"X-Approver": "reviewer-42"},
        )
        require(
            repeated.json() == approved.json(),
            "idempotent replay changed response",
        )
        reused_key = await client.post(
            "/runs/demo/resume",
            json={
                "decision": "reject",
                "expected_version": 1,
                "idempotency_key": "approve-demo-001",
            },
            headers={"X-Approver": "reviewer-42"},
        )
        require(reused_key.status_code == 409, "idempotency key reuse was accepted")
        decision_replay = await client.get(
            "/runs/demo/events",
            params={"follow": "false"},
            headers={"Last-Event-ID": "2"},
        )
        require("id: 3" in decision_replay.text, "resume event id is not monotonic")
        require("event: decision" in decision_replay.text, "resume event was lost")
        conflicting = await client.post(
            "/runs/demo/resume",
            json={
                "decision": "reject",
                "expected_version": 2,
                "idempotency_key": "reject-demo-001",
            },
            headers={"X-Approver": "reviewer-42"},
        )
        require(conflicting.status_code == 409, "terminal run changed state")


def self_test() -> None:
    asyncio.run(verify_http_api())

    protocol = asyncio.run(verify_mcp_protocol())
    require("query_inventory" in protocol["tools"], "MCP tool was not listed")
    require(
        protocol["structured_content"]["available"] == 240,
        "MCP call result mismatch",
    )
    require(
        any(getattr(route, "path", None) == "/mcp" for route in app.routes),
        "MCP transport not mounted",
    )
    mounted_protocol = asyncio.run(verify_mounted_mcp_transport())
    require(
        mounted_protocol["structured_content"]["available"] == 240,
        "mounted MCP transport call failed",
    )
    print("p08 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    elif args.serve:
        uvicorn.run(app, host="127.0.0.1", port=8000)
    else:
        protocol = asyncio.run(verify_mcp_protocol())
        print(
            json.dumps(
                {
                    "routes": [
                        "/health",
                        "/runs/demo/events",
                        "/runs/demo/resume",
                        "/mcp",
                    ],
                    "mcp": protocol,
                },
                ensure_ascii=False,
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
