# p08 — FastAPI, SSE and MCP

## 功能

服务端用 SSE 单向发送带持久、单调递增 id 的计划、状态与审批事件，并支持 `Last-Event-ID` 重连。默认连接会持续跟随等待审批的运行，并在进入终态后关闭；`?follow=false` 用于一次性回放。审批通过独立 `POST /runs/{id}/resume` 回传，要求审批身份、期望版本和幂等键；同一幂等键若携带不同请求指纹会被拒绝。ERP 查询函数注册为真实 FastMCP 工具，MCP Streamable HTTP transport 挂载在 `/mcp/`。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认使用进程内状态与 ASGI 测试，不需要外部 ERP
- 手工 HTTP 验证需要本机端口 `8000` 可用

## 安装与运行

```bash
python -m pip install -r requirements.txt
./test.sh
python main.py --serve
```

另一个终端：

```bash
curl -N http://127.0.0.1:8000/runs/demo/events
curl -X POST http://127.0.0.1:8000/runs/demo/resume \
  -H 'x-approver: reviewer-42' \
  -H 'content-type: application/json' \
  -d '{"decision":"approve","expected_version":1,"idempotency_key":"approve-demo-001"}'
```

## 示例输出

```text
id: 1
event: plan
data: "采购计划已生成"

id: 2
event: status
data: {"status": "waiting_approval", "version": 1}
```

MCP endpoint：

```text
http://127.0.0.1:8000/mcp/
```

父 FastAPI 会接管 FastMCP HTTP 应用的 lifespan，确保 Streamable HTTP 会话管理器随服务启动。自测显式启动该生命周期，再使用 FastMCP `Client` 通过已挂载的 ASGI transport 完成真实 `list_tools` 和 `call_tool` 协议调用。

演示仍使用进程内状态；生产服务必须将 run、checkpoint、事件游标与幂等键写入持久存储，并接入真实认证系统。
