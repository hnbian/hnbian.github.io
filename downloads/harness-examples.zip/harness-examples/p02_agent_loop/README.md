# p02 — Layered agent loop

## 功能

案例把工具执行从 Agent 决策中拆开，并让策略与追踪以中间件组合。安全策略先于工具执行；追踪记录结构化参数、结果和错误。`RetryPolicy` 只有在异常是 `TransientToolError` 且工具显式列入 `retryable_tools` 时才重试，并限制最大尝试次数；权限错误和未列入白名单的副作用工具不会被重试。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 仅使用标准库；库存数据是离线夹具

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py
./test.sh
```

## 示例输出

```json
{
  "result": {"available": 240, "warehouse": "SHA-01"},
  "trace": [
    {"phase": "before", "tool": "inventory"},
    {"phase": "after", "tool": "inventory"}
  ]
}
```

测试验证正常库存查询、危险工具拒绝、一次瞬态失败后成功，以及未知结果的副作用工具不会自动重试。
