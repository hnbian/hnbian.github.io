#!/usr/bin/env python3
"""Layered harness runtime with policy, tracing and bounded retries."""

from __future__ import annotations

import argparse
import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Protocol


class Middleware(Protocol):
    def before_tool(self, context: RunContext, name: str, arguments: dict[str, Any]) -> None: ...
    def after_tool(self, context: RunContext, name: str, result: Any) -> None: ...
    def on_tool_error(self, context: RunContext, name: str, error: Exception) -> None: ...


@dataclass
class RunContext:
    user_id: str
    events: list[dict[str, Any]] = field(default_factory=list)


class PolicyMiddleware:
    def __init__(self, denied_tools: set[str]):
        self.denied_tools = denied_tools

    def before_tool(self, context: RunContext, name: str, arguments: dict[str, Any]) -> None:
        if name in self.denied_tools:
            raise PermissionError(f"policy denied tool: {name}")

    def after_tool(self, context: RunContext, name: str, result: Any) -> None:
        return None

    def on_tool_error(self, context: RunContext, name: str, error: Exception) -> None:
        return None


class TraceMiddleware:
    def before_tool(self, context: RunContext, name: str, arguments: dict[str, Any]) -> None:
        context.events.append({"phase": "before", "tool": name, "arguments": arguments})

    def after_tool(self, context: RunContext, name: str, result: Any) -> None:
        context.events.append({"phase": "after", "tool": name, "result": result})

    def on_tool_error(self, context: RunContext, name: str, error: Exception) -> None:
        context.events.append(
            {
                "phase": "error",
                "tool": name,
                "error_type": type(error).__name__,
                "message": str(error),
            }
        )


class TransientToolError(RuntimeError):
    """A retryable tool failure such as a temporary upstream outage."""


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 1
    backoff_seconds: float = 0.0
    retryable_errors: tuple[type[Exception], ...] = (TransientToolError,)
    retryable_tools: frozenset[str] = frozenset()

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be at least 1")
        if self.backoff_seconds < 0:
            raise ValueError("backoff_seconds must be non-negative")


class Runtime:
    def __init__(
        self,
        tools: dict[str, Callable[..., Any]],
        middleware: list[Middleware],
        retry_policy: RetryPolicy | None = None,
    ):
        self.tools = tools
        self.middleware = middleware
        self.retry_policy = retry_policy or RetryPolicy()

    def call_tool(self, context: RunContext, name: str, **arguments: Any) -> Any:
        if name not in self.tools:
            raise KeyError(f"unknown tool: {name}")
        for attempt in range(1, self.retry_policy.max_attempts + 1):
            try:
                for layer in self.middleware:
                    layer.before_tool(context, name, arguments)
                result = self.tools[name](**arguments)
                for layer in reversed(self.middleware):
                    layer.after_tool(context, name, result)
                return result
            except Exception as error:
                for layer in reversed(self.middleware):
                    layer.on_tool_error(context, name, error)
                retryable = (
                    isinstance(error, self.retry_policy.retryable_errors)
                    and name in self.retry_policy.retryable_tools
                )
                if not retryable or attempt == self.retry_policy.max_attempts:
                    raise
                if self.retry_policy.backoff_seconds:
                    time.sleep(self.retry_policy.backoff_seconds)
        raise AssertionError("retry loop exhausted without returning or raising")


def inventory(sku: str) -> dict[str, Any]:
    records = {"M8-BOLT": {"available": 240, "warehouse": "SHA-01"}}
    return records.get(sku, {"available": 0, "warehouse": None})


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    runtime = Runtime(
        {"inventory": inventory, "delete_erp": lambda: True},
        [PolicyMiddleware({"delete_erp"}), TraceMiddleware()],
    )
    context = RunContext("demo-user")
    result = runtime.call_tool(context, "inventory", sku="M8-BOLT")
    require(result["available"] == 240, "inventory result mismatch")
    require(
        [event["phase"] for event in context.events] == ["before", "after"],
        "trace order mismatch",
    )
    try:
        runtime.call_tool(context, "delete_erp")
    except PermissionError:
        pass
    else:
        raise AssertionError("policy did not deny dangerous tool")

    calls = 0

    def flaky_inventory(sku: str) -> dict[str, Any]:
        nonlocal calls
        calls += 1
        if calls == 1:
            raise TransientToolError("temporary ERP outage")
        return inventory(sku)

    retry_context = RunContext("retry-user")
    retry_runtime = Runtime(
        {"inventory": flaky_inventory},
        [TraceMiddleware()],
        RetryPolicy(max_attempts=2, retryable_tools=frozenset({"inventory"})),
    )
    retry_result = retry_runtime.call_tool(retry_context, "inventory", sku="M8-BOLT")
    require(calls == 2, "transient error was not retried exactly once")
    require(retry_result["available"] == 240, "retry result mismatch")
    require(
        [event["phase"] for event in retry_context.events]
        == ["before", "error", "before", "after"],
        "retry trace mismatch",
    )
    side_effect_calls = 0

    def unsafe_side_effect() -> None:
        nonlocal side_effect_calls
        side_effect_calls += 1
        raise TransientToolError("outcome is unknown")

    unsafe_runtime = Runtime(
        {"submit_order": unsafe_side_effect},
        [TraceMiddleware()],
        RetryPolicy(max_attempts=3),
    )
    try:
        unsafe_runtime.call_tool(RunContext("unsafe-retry-user"), "submit_order")
    except TransientToolError:
        pass
    else:
        raise AssertionError("side-effecting failure was swallowed")
    require(side_effect_calls == 1, "non-allow-listed side effect was retried")
    print("p02 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    context = RunContext("demo-user")
    runtime = Runtime({"inventory": inventory}, [PolicyMiddleware(set()), TraceMiddleware()])
    result = runtime.call_tool(context, "inventory", sku="M8-BOLT")
    print(json.dumps({"result": result, "trace": context.events}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
