# p10 — Deterministic procurement workflow Harness

## 功能

端到端流程使用真实 LangGraph StateGraph、checkpointer、`interrupt()` 和 `Command(resume=...)`，包含库存、供应商资格、用户账期偏好、报价选择、金额阈值审批和 Markdown 报告。默认先停在审批点：

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认使用离线库存与报价，不需要模型或 ERP
- `--report` 指定的父目录必须可写

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py
python main.py --decision approve --report reports/purchase.md
./test.sh
```

## 示例输出

```json
{
  "sku": "M8-BOLT",
  "shortage": 260,
  "selected_quote": {
    "supplier": "华东紧固件",
    "unit_price": "0.42"
  },
  "total": "109.20",
  "status": "waiting_approval"
}
```

M8-BOLT、供应商和金额是为离线回归重新设计的测试夹具，不是课程字幕中的原始业务数据。金额计算使用 `Decimal`，JSON 中以精确十进制字符串输出。确定性数据使业务规则可以稳定回归：

- 需求 500，库存 240，缺口 260；
- 更低价的联成工业只有 15 天账期，不满足用户的 30 天偏好；
- 未知贸易商未通过资格审查；
- 选择华东紧固件后总额 109.20，超过 100 元演示阈值，需要审批。

测试覆盖无缺口不选供应商、负需求拒绝、未知 SKU、金额等于阈值、批准、拒绝、重复恢复和重复 run id 拒绝。生产替换点是库存/订单 MCP 工具、供应商调研子代理、数据库 checkpointer、OpenSandbox backend 和对象存储报告；确定性业务判定和审批边界可保留。
