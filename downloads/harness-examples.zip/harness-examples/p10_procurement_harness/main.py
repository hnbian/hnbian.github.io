#!/usr/bin/env python3
"""Deterministic procurement workflow with resumable in-process HITL."""

from __future__ import annotations

import argparse
import json
import threading
import uuid
from dataclasses import asdict, dataclass
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, NotRequired, Required, TypedDict

from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt


@dataclass(frozen=True)
class Quote:
    supplier: str
    unit_price: Decimal
    payment_days: int
    qualified: bool


class ProcurementState(TypedDict, total=False):
    sku: Required[str]
    required: Required[int]
    minimum_payment_days: Required[int]
    report_path: NotRequired[str]
    available: NotRequired[int]
    shortage: NotRequired[int]
    selected_quote: NotRequired[dict[str, object] | None]
    total: NotRequired[Decimal]
    needs_approval: NotRequired[bool]
    approved: NotRequired[bool]
    status: NotRequired[str]
    approval: NotRequired[dict[str, str]]
    plan: NotRequired[list[dict[str, str]]]


def initial_plan() -> list[dict[str, str]]:
    return [
        {"content": "查询库存", "status": "pending"},
        {"content": "筛选合格报价", "status": "pending"},
        {"content": "计算采购建议", "status": "pending"},
        {"content": "人工审批", "status": "pending"},
        {"content": "生成报告", "status": "pending"},
    ]


class ProcurementHarness:
    """LangGraph workflow around deterministic, independently testable rules."""

    def __init__(
        self,
        approval_threshold: Decimal | int | float | str = Decimal("100.00"),
    ):
        if isinstance(approval_threshold, bool):
            raise ValueError("approval_threshold must be positive")
        try:
            threshold = Decimal(str(approval_threshold))
        except (InvalidOperation, ValueError):
            raise ValueError("approval_threshold must be a finite number") from None
        if not threshold.is_finite() or threshold <= 0:
            raise ValueError("approval_threshold must be positive")
        self.approval_threshold = threshold
        self.inventory = {"M8-BOLT": 240}
        self.quotes = {
            "M8-BOLT": [
                Quote("华东紧固件", Decimal("0.42"), 30, True),
                Quote("联成工业", Decimal("0.39"), 15, True),
                Quote("未知贸易商", Decimal("0.31"), 60, False),
            ]
        }
        self._run_ids: set[str] = set()
        self._run_ids_lock = threading.RLock()
        self.graph = self._build_graph()

    @staticmethod
    def _validate_input(
        sku: str,
        required: int,
        minimum_payment_days: int,
    ) -> None:
        if not isinstance(sku, str) or not sku.strip():
            raise ValueError("sku is required")
        if isinstance(required, bool) or not isinstance(required, int) or required < 0:
            raise ValueError("required must be non-negative")
        if (
            isinstance(minimum_payment_days, bool)
            or not isinstance(minimum_payment_days, int)
            or minimum_payment_days < 0
        ):
            raise ValueError("minimum_payment_days must be non-negative")

    def _analyze(self, state: ProcurementState) -> dict[str, Any]:
        self._validate_input(
            state["sku"],
            state["required"],
            state["minimum_payment_days"],
        )
        plan = initial_plan()
        available = self.inventory.get(state["sku"], 0)
        shortage = max(0, state["required"] - available)
        plan[0]["status"] = "completed"

        if shortage == 0:
            plan[1]["status"] = "skipped"
            plan[2]["status"] = "completed"
            return {
                "available": available,
                "shortage": 0,
                "selected_quote": None,
                "total": 0.0,
                "needs_approval": False,
                "status": "ready_to_report",
                "plan": plan,
            }

        eligible = [
            quote
            for quote in self.quotes.get(state["sku"], [])
            if quote.qualified
            and quote.payment_days >= state["minimum_payment_days"]
            and quote.unit_price > 0
        ]
        if not eligible:
            raise ValueError("no qualified quote satisfies user preferences")
        selected = min(eligible, key=lambda quote: quote.unit_price)
        total = (Decimal(shortage) * selected.unit_price).quantize(
            Decimal("0.01"),
            rounding=ROUND_HALF_UP,
        )
        plan[1]["status"] = "completed"
        plan[2]["status"] = "completed"
        return {
            "available": available,
            "shortage": shortage,
            "selected_quote": asdict(selected),
            "total": total,
            "needs_approval": total >= self.approval_threshold,
            "status": "ready_for_approval",
            "plan": plan,
        }

    @staticmethod
    def _route_after_analyze(state: ProcurementState) -> str:
        return "approval" if state.get("needs_approval", False) else "report"

    @staticmethod
    def _approval(state: ProcurementState) -> dict[str, Any]:
        shortage = state.get("shortage")
        total = state.get("total")
        plan_state = state.get("plan")
        if shortage is None or total is None or plan_state is None:
            raise RuntimeError("approval node received incomplete analyzed state")
        decision = interrupt(
            {
                "kind": "purchase_approval",
                "sku": state["sku"],
                "shortage": shortage,
                "total": total,
                "selected_quote": state.get("selected_quote"),
                "allowed_decisions": ["approve", "reject"],
            }
        )
        if not isinstance(decision, dict):
            raise ValueError("resume payload must be an object")
        decision_name = decision.get("decision")
        approver = decision.get("approver")
        reason = decision.get("reason", "")
        if decision_name not in {"approve", "reject"}:
            raise ValueError("decision must be approve or reject")
        if not isinstance(approver, str) or not approver.strip():
            raise ValueError("authenticated approver is required")
        approver = approver.strip()
        plan = [dict(item) for item in plan_state]
        plan[3]["status"] = "approved" if decision_name == "approve" else "rejected"
        return {
            "approved": decision_name == "approve",
            "approval": {
                "decision": decision_name,
                "approver": approver,
                "reason": str(reason),
            },
            "status": "approved" if decision_name == "approve" else "rejected",
            "plan": plan,
        }

    @staticmethod
    def _route_after_approval(state: ProcurementState) -> str:
        return "report" if state.get("approved", False) else END

    def _report(self, state: ProcurementState) -> dict[str, Any]:
        plan_state = state.get("plan")
        if plan_state is None:
            raise RuntimeError("report node received no plan")
        plan = [dict(item) for item in plan_state]
        if not state.get("needs_approval", False):
            plan[3]["status"] = "skipped"
        plan[4]["status"] = "completed"
        result: dict[str, Any] = {
            "status": "completed",
            "plan": plan,
        }
        report_path = state.get("report_path")
        if report_path:
            path = Path(report_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            preview = dict(state)
            preview.update(result)
            path.write_text(self.render_report(preview), encoding="utf-8")
        return result

    def _build_graph(self):
        builder = StateGraph(ProcurementState)
        builder.add_node("analyze", self._analyze)
        builder.add_node("approval", self._approval)
        builder.add_node("report", self._report)
        builder.add_edge(START, "analyze")
        builder.add_conditional_edges(
            "analyze",
            self._route_after_analyze,
            {"approval": "approval", "report": "report"},
        )
        builder.add_conditional_edges(
            "approval",
            self._route_after_approval,
            {"report": "report", END: END},
        )
        builder.add_edge("report", END)
        return builder.compile(checkpointer=InMemorySaver())

    @staticmethod
    def _config(run_id: str) -> RunnableConfig:
        return {"configurable": {"thread_id": run_id}}

    @staticmethod
    def _public_result(result: dict[str, Any]) -> dict[str, Any]:
        output = {
            key: value
            for key, value in result.items()
            if key not in {"__interrupt__", "report_path"}
        }
        interrupts = result.get("__interrupt__", ())
        if interrupts:
            output["status"] = "waiting_approval"
            output["interrupt"] = interrupts[0].value
        return output

    def start(
        self,
        sku: str,
        required: int,
        *,
        minimum_payment_days: int,
        run_id: str | None = None,
        report_path: Path | None = None,
    ) -> tuple[str, dict[str, Any]]:
        self._validate_input(sku, required, minimum_payment_days)
        if run_id is not None and not run_id.strip():
            raise ValueError("run_id must not be blank")
        resolved_run_id = run_id or uuid.uuid4().hex
        with self._run_ids_lock:
            if resolved_run_id in self._run_ids:
                raise ValueError(f"run_id already exists: {resolved_run_id}")
            self._run_ids.add(resolved_run_id)
        state: ProcurementState = {
            "sku": sku,
            "required": required,
            "minimum_payment_days": minimum_payment_days,
        }
        if report_path:
            state["report_path"] = str(report_path)
        result = self.graph.invoke(state, self._config(resolved_run_id))
        return resolved_run_id, self._public_result(result)

    def resume(
        self,
        run_id: str,
        *,
        decision: str,
        approver: str,
        reason: str = "",
    ) -> dict[str, Any]:
        if decision not in {"approve", "reject"}:
            raise ValueError("decision must be approve or reject")
        if not approver.strip():
            raise ValueError("authenticated approver is required")
        approver = approver.strip()
        snapshot = self.graph.get_state(self._config(run_id))
        if not snapshot.next:
            raise RuntimeError("run is not waiting for approval")
        result = self.graph.invoke(
            Command(
                resume={
                    "decision": decision,
                    "approver": approver,
                    "reason": reason,
                }
            ),
            self._config(run_id),
        )
        return self._public_result(result)

    def run(
        self,
        sku: str,
        required: int,
        *,
        minimum_payment_days: int,
        approved: bool | None,
        approver: str = "demo-approver",
        report_path: Path | None = None,
    ) -> dict[str, Any]:
        run_id, result = self.start(
            sku,
            required,
            minimum_payment_days=minimum_payment_days,
            report_path=report_path,
        )
        if result["status"] == "waiting_approval":
            if approved is None:
                result["run_id"] = run_id
                return result
            return self.resume(
                run_id,
                decision="approve" if approved else "reject",
                approver=approver,
            )
        if approved is not None:
            raise ValueError("approval decision supplied for a run that needs no approval")
        result["run_id"] = run_id
        return result

    @staticmethod
    def render_report(result: dict[str, Any]) -> str:
        quote = result.get("selected_quote") or {}
        return (
            "# 采购建议\n\n"
            f"- SKU: {result['sku']}\n"
            f"- 需求数量: {result['required']}\n"
            f"- 当前库存: {result['available']}\n"
            f"- 建议采购: {result['shortage']}\n"
            f"- 供应商: {quote.get('supplier', '无需采购')}\n"
            f"- 总金额: {result['total']}\n"
            f"- 状态: {result['status']}\n"
        )


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def json_default(value: object) -> str:
    if isinstance(value, Decimal):
        return format(value, "f")
    raise TypeError(f"{type(value).__name__} is not JSON serializable")


def self_test() -> None:
    harness = ProcurementHarness(approval_threshold=100)
    run_id, paused = harness.start(
        "M8-BOLT",
        500,
        minimum_payment_days=30,
        run_id="purchase-paused",
    )
    require(paused["status"] == "waiting_approval", "workflow did not interrupt")
    require(
        paused["selected_quote"]["supplier"] == "华东紧固件",
        "supplier selection mismatch",
    )
    approved = harness.resume(
        run_id,
        decision="approve",
        approver="reviewer-42",
        reason="budget confirmed",
    )
    require(approved["status"] == "completed", "approved workflow did not finish")
    require(approved["approval"]["approver"] == "reviewer-42", "approval audit missing")
    try:
        harness.resume(run_id, decision="reject", approver="reviewer-42")
    except RuntimeError:
        pass
    else:
        raise AssertionError("terminal workflow accepted a second decision")
    try:
        harness.start(
            "M8-BOLT",
            500,
            minimum_payment_days=30,
            run_id="purchase-paused",
        )
    except ValueError:
        pass
    else:
        raise AssertionError("duplicate run_id was accepted")

    _, rejected_pause = harness.start(
        "M8-BOLT",
        500,
        minimum_payment_days=30,
        run_id="purchase-rejected",
    )
    require(rejected_pause["status"] == "waiting_approval", "reject setup failed")
    rejected = harness.resume(
        "purchase-rejected",
        decision="reject",
        approver="reviewer-7",
        reason="budget unavailable",
    )
    require(rejected["status"] == "rejected", "reject path failed")
    require(rejected["plan"][3]["status"] == "rejected", "reject state missing")

    no_purchase = harness.run(
        "M8-BOLT",
        5,
        minimum_payment_days=30,
        approved=None,
    )
    require(no_purchase["shortage"] == 0, "no-shortage calculation failed")
    require(no_purchase["selected_quote"] is None, "supplier selected without shortage")
    require(
        no_purchase["plan"][3]["status"] == "skipped",
        "approval was not skipped",
    )

    with TemporaryDirectory() as temp:
        report_path = Path(temp) / "purchase.md"
        completed = harness.run(
            "M8-BOLT",
            500,
            minimum_payment_days=30,
            approved=True,
            report_path=report_path,
        )
        require(completed["total"] == Decimal("109.20"), "total mismatch")
        require("华东紧固件" in report_path.read_text(encoding="utf-8"), "report missing")

    exact_threshold = ProcurementHarness(approval_threshold=Decimal("109.20"))
    _, exact = exact_threshold.start(
        "M8-BOLT",
        500,
        minimum_payment_days=30,
    )
    require(exact["status"] == "waiting_approval", "equal threshold skipped approval")

    for invalid_required in (-1,):
        try:
            harness.run(
                "M8-BOLT",
                invalid_required,
                minimum_payment_days=30,
                approved=None,
            )
        except ValueError:
            pass
        else:
            raise AssertionError("negative demand was accepted")
    try:
        harness.run(
            "UNKNOWN",
            1,
            minimum_payment_days=30,
            approved=None,
        )
    except ValueError:
        pass
    else:
        raise AssertionError("unknown SKU without quotes was accepted")
    print("p10 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sku", default="M8-BOLT")
    parser.add_argument("--required", type=int, default=500)
    parser.add_argument("--minimum-payment-days", type=int, default=30)
    parser.add_argument(
        "--decision",
        choices=["approve", "reject", "pending"],
        default="pending",
    )
    parser.add_argument("--approver", default="demo-approver")
    parser.add_argument("--report", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    decision = None if args.decision == "pending" else args.decision == "approve"
    result = ProcurementHarness().run(
        args.sku,
        args.required,
        minimum_payment_days=args.minimum_payment_days,
        approved=decision,
        approver=args.approver,
        report_path=args.report,
    )
    print(
        json.dumps(
            result,
            ensure_ascii=False,
            indent=2,
            default=json_default,
        )
    )


if __name__ == "__main__":
    main()
