#!/usr/bin/env bash
set -euo pipefail
python_bin="${PYTHON_BIN:-python3}"
"$python_bin" -c 'import sys; raise SystemExit(sys.version_info < (3, 11))'
"$python_bin" main.py --self-test
