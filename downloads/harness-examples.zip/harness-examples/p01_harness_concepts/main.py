#!/usr/bin/env python3
"""A deterministic, bounded Agent Harness loop with an allow-listed tool."""

from __future__ import annotations

import argparse
import ast
import json
import operator
from collections.abc import Callable
from dataclasses import asdict, dataclass

OPS: dict[type[ast.operator], Callable[[float, float], float]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}


def safe_calculate(expression: str) -> float:
    """Evaluate only numeric binary arithmetic; never execute Python code."""

    def visit(node: ast.AST) -> float:
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if (
            isinstance(node, ast.Constant)
            and isinstance(node.value, (int, float))
            and not isinstance(node.value, bool)
        ):
            return float(node.value)
        if isinstance(node, ast.BinOp) and type(node.op) in OPS:
            return OPS[type(node.op)](visit(node.left), visit(node.right))
        raise ValueError("only numeric +, -, *, / expressions are allowed")

    if len(expression) > 100:
        raise ValueError("expression is too long")
    return visit(ast.parse(expression, mode="eval"))


@dataclass(frozen=True)
class Event:
    kind: str
    detail: str


class DeterministicModel:
    """Small model double: it chooses a tool, then turns observation into an answer."""

    def decide(self, question: str, observation: str | None) -> dict[str, str]:
        if observation is not None:
            return {"answer": f"计算结果是 {observation}"}
        expression = question.removeprefix("计算").strip()
        return {"tool": "calculator", "argument": expression}


class Harness:
    def __init__(self, tools: dict[str, Callable[[str], object]], max_steps: int = 3):
        self.tools = tools
        self.max_steps = max_steps

    def run(self, question: str) -> tuple[str, list[Event]]:
        model = DeterministicModel()
        observation: str | None = None
        events = [Event("input", question)]
        for _ in range(self.max_steps):
            action = model.decide(question, observation)
            if "answer" in action:
                events.append(Event("answer", action["answer"]))
                return action["answer"], events
            tool_name = action["tool"]
            if tool_name not in self.tools:
                raise PermissionError(f"tool is not allow-listed: {tool_name}")
            events.append(Event("tool_call", f"{tool_name}({action['argument']})"))
            observation = str(self.tools[tool_name](action["argument"]))
            events.append(Event("tool_result", observation))
        raise RuntimeError("maximum harness steps exceeded")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    answer, events = Harness({"calculator": safe_calculate}).run("计算 12 * 8")
    require(answer == "计算结果是 96.0", "calculation result mismatch")
    require(
        [event.kind for event in events] == ["input", "tool_call", "tool_result", "answer"],
        "agent loop event order mismatch",
    )
    try:
        safe_calculate("__import__('os').system('id')")
    except ValueError:
        pass
    else:
        raise AssertionError("unsafe expression was accepted")
    try:
        safe_calculate("True + 1")
    except ValueError:
        pass
    else:
        raise AssertionError("boolean literal was accepted as a number")
    print("p01 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("question", nargs="?", default="计算 12 * 8")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    answer, events = Harness({"calculator": safe_calculate}).run(args.question)
    print(
        json.dumps(
            {"answer": answer, "events": [asdict(e) for e in events]}, ensure_ascii=False, indent=2
        )
    )


if __name__ == "__main__":
    main()
