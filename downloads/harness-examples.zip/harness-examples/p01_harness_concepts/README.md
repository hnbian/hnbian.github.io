# p01 — Harness concepts

## 功能

这个案例把 Harness 压缩为四件可观察的事：模型决策、工具白名单、反馈回注、最大步数。计算器使用 AST 白名单，不调用危险的 `eval`。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 仅使用标准库，不需要模型密钥或外部服务

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py "计算 15 / 3"
./test.sh
```

## 示例输出

```json
{
  "answer": "计算结果是 5.0",
  "events": [
    {"kind": "tool_call", "detail": "calculator(15 / 3)"},
    {"kind": "tool_result", "detail": "5.0"}
  ]
}
```

预期输出包含 `tool_call`、`tool_result` 和最终答案。测试还会确认 Python 代码注入被拒绝。
