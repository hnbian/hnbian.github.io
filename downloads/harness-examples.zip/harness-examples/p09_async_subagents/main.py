#!/usr/bin/env python3
"""Real AsyncSubAgent graph wiring plus a correct local lifecycle model."""

from __future__ import annotations

import argparse
import json
import os
import threading
import time
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from typing import Any

from deepagents import AsyncSubAgent, create_deep_agent
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage

TERMINAL_STATUSES = {"completed", "failed", "cancelled"}
ASYNC_TOOL_NAMES = {
    "start_async_task",
    "check_async_task",
    "update_async_task",
    "cancel_async_task",
    "list_async_tasks",
}


@dataclass
class TaskRecord:
    task_id: str
    description: str
    status: str = "queued"
    result: str | None = None
    error: str | None = None
    updates: list[str] = field(default_factory=list)


@dataclass
class TaskControl:
    cancel_requested: threading.Event = field(default_factory=threading.Event)


class ToolAwareFakeModel(FakeMessagesListChatModel):
    def bind_tools(
        self,
        tools: Any,
        *,
        tool_choice: str | None = None,
        **kwargs: Any,
    ) -> ToolAwareFakeModel:
        return self


class TaskManager:
    """Cooperative local task model; it does not pretend to be Agent Protocol."""

    def __init__(self, max_workers: int = 2) -> None:
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.records: dict[str, TaskRecord] = {}
        self.controls: dict[str, TaskControl] = {}
        self.futures: dict[str, Future[None]] = {}
        self.lock = threading.RLock()

    def start(
        self,
        description: str,
        *,
        steps: int = 8,
        step_delay: float = 0.01,
    ) -> str:
        if not description.strip():
            raise ValueError("description is required")
        if steps < 1 or step_delay < 0:
            raise ValueError("steps must be positive and delay non-negative")
        task_id = uuid.uuid4().hex
        with self.lock:
            self.records[task_id] = TaskRecord(task_id, description)
            self.controls[task_id] = TaskControl()
            self.futures[task_id] = self.executor.submit(
                self._work,
                task_id,
                steps,
                step_delay,
            )
        return task_id

    def _work(self, task_id: str, steps: int, step_delay: float) -> None:
        try:
            with self.lock:
                record = self.records[task_id]
                if self.controls[task_id].cancel_requested.is_set():
                    record.status = "cancelled"
                    return
                record.status = "running"
            for _ in range(steps):
                if self.controls[task_id].cancel_requested.wait(step_delay):
                    with self.lock:
                        self.records[task_id].status = "cancelled"
                    return
                with self.lock:
                    record = self.records[task_id]
                    if record.updates:
                        record.description = record.updates[-1]
            with self.lock:
                record = self.records[task_id]
                record.result = f"completed: {record.description}"
                record.status = "completed"
        except Exception as error:
            with self.lock:
                record = self.records[task_id]
                record.error = f"{type(error).__name__}: {error}"
                record.status = "failed"

    def check(self, task_id: str) -> TaskRecord:
        with self.lock:
            if task_id not in self.records:
                raise KeyError(task_id)
            return TaskRecord(**asdict(self.records[task_id]))

    def update(self, task_id: str, description: str) -> TaskRecord:
        if not description.strip():
            raise ValueError("description is required")
        with self.lock:
            record = self.records[task_id]
            if record.status in TERMINAL_STATUSES:
                raise RuntimeError("terminal tasks cannot be updated")
            record.updates.append(description)
            record.description = description
            return TaskRecord(**asdict(record))

    def cancel(self, task_id: str) -> TaskRecord:
        with self.lock:
            record = self.records[task_id]
            if record.status in TERMINAL_STATUSES:
                return TaskRecord(**asdict(record))
            self.controls[task_id].cancel_requested.set()
            if self.futures[task_id].cancel():
                record.status = "cancelled"
            else:
                record.status = "cancelling"
            return TaskRecord(**asdict(record))

    def list(self) -> list[TaskRecord]:
        with self.lock:
            task_ids = list(self.records)
        return [self.check(task_id) for task_id in task_ids]

    def wait(self, task_id: str, timeout: float = 2.0) -> TaskRecord:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            record = self.check(task_id)
            if record.status in TERMINAL_STATUSES:
                return record
            time.sleep(0.005)
        raise TimeoutError(f"task {task_id} did not reach a terminal state")

    def close(self) -> None:
        self.executor.shutdown(wait=True)


def async_subagent_spec(
    url: str = "http://127.0.0.1:2024",
    token: str | None = None,
) -> AsyncSubAgent:
    spec: AsyncSubAgent = {
        "name": "supplier-research",
        "description": "Research suppliers without blocking the supervisor.",
        "graph_id": "supplier_research",
        "url": url,
    }
    if token:
        spec["headers"] = {"authorization": f"Bearer {token}"}
    return spec


def public_async_subagent_spec(
    url: str,
    token: str | None,
) -> dict[str, Any]:
    """Return a display-safe copy that never exposes the bearer token."""

    spec: dict[str, Any] = dict(async_subagent_spec(url, token))
    if "headers" in spec:
        spec["headers"] = {"authorization": "Bearer [redacted]"}
    return spec


def build_real_async_supervisor(
    url: str = "http://127.0.0.1:2024",
    token: str | None = None,
):
    """Build a real Deep Agents graph containing the five async task tools."""

    model = ToolAwareFakeModel(responses=[AIMessage(content="异步任务系统已就绪。")])
    return create_deep_agent(
        model=model,
        subagents=[async_subagent_spec(url, token)],
        name="async_supervisor",
    )


def registered_async_tools(agent: Any) -> list[str]:
    tools = agent.nodes["tools"].bound.tools_by_name
    return sorted(name for name in tools if name in ASYNC_TOOL_NAMES)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def self_test() -> None:
    require(
        AsyncSubAgent.__required_keys__ == {"name", "description", "graph_id"},
        "AsyncSubAgent required fields changed",
    )
    require(
        AsyncSubAgent.__optional_keys__ == {"url", "headers"},
        "AsyncSubAgent optional fields changed",
    )
    spec = async_subagent_spec(token="test-token")
    require("headers" in spec, "optional authentication headers missing")
    public_spec = public_async_subagent_spec("http://127.0.0.1:2024", "test-token")
    require("test-token" not in json.dumps(public_spec), "authentication token leaked")

    real_agent = build_real_async_supervisor(token="test-token")
    require(
        set(registered_async_tools(real_agent)) == ASYNC_TOOL_NAMES,
        "real Deep Agents graph does not expose all five async tools",
    )

    manager = TaskManager(max_workers=1)
    try:
        task_id = manager.start("compare suppliers", steps=20)
        manager.update(task_id, "compare qualified suppliers")
        completed = manager.wait(task_id)
        require(completed.status == "completed", "updated task did not complete")
        require(
            completed.result == "completed: compare qualified suppliers",
            "update did not affect worker execution",
        )

        cancelled_id = manager.start("long supplier crawl", steps=200)
        deadline = time.monotonic() + 1
        while manager.check(cancelled_id).status == "queued" and time.monotonic() < deadline:
            time.sleep(0.005)
        manager.cancel(cancelled_id)
        cancelled = manager.wait(cancelled_id)
        require(cancelled.status == "cancelled", "running task was not cancelled")
        require(len(manager.list()) == 2, "task listing lost records")
    finally:
        manager.close()
    print("p09 self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument(
        "--agent-url",
        default=os.getenv("AGENT_SERVER_URL", "http://127.0.0.1:2024"),
    )
    parser.add_argument("--token", default=os.getenv("AGENT_SERVER_TOKEN"))
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return

    agent = build_real_async_supervisor(args.agent_url, args.token)
    manager = TaskManager()
    try:
        task_id = manager.start("后台供应商调研")
        task = manager.wait(task_id)
        print(
            json.dumps(
                {
                    "spec": public_async_subagent_spec(args.agent_url, args.token),
                    "registered_tools": registered_async_tools(agent),
                    "local_lifecycle_demo": asdict(task),
                    "remote_integration": (
                        "graph wiring verified; remote execution also requires "
                        "an Agent Protocol server and a supervisor invocation "
                        "that calls start_async_task"
                    ),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    finally:
        manager.close()


if __name__ == "__main__":
    main()
