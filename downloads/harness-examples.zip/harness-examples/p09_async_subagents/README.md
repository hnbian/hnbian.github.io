# p09 — Async subagents

## 功能

案例做三层验证：

1. 直接导入 Deep Agents 0.6.12 的 `AsyncSubAgent`，检查必需字段和可选 `url / headers`。
2. 创建真实 Deep Agents Supervisor 图，确认五个异步工具均已注册。
3. 用明确标注的本地协作式执行器测试 update 确实改变执行结果、cancel 确实终止运行任务；它不伪装成 Agent Protocol Server。

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认本地生命周期演示不需要 Agent Server
- 远程路径需要 Agent Protocol Server、对应 graph 和可选 bearer token

## 安装与运行

```bash
python -m pip install -r requirements.txt
python main.py
./test.sh
```

## 示例输出

```json
{
  "registered_tools": [
    "cancel_async_task",
    "check_async_task",
    "list_async_tasks",
    "start_async_task",
    "update_async_task"
  ],
  "local_lifecycle_demo": {
    "status": "completed",
    "result": "completed: 后台供应商调研"
  }
}
```

若把该图接入真实模型并触发 `start_async_task`，还需要同进程 ASGI 图或 `--agent-url` 指向的 Agent Protocol Server：

```bash
python main.py --agent-url http://127.0.0.1:2024
```

也可以通过 `.env.example` 中的 `AGENT_SERVER_URL` 和 `AGENT_SERVER_TOKEN` 提供默认值；命令行参数优先。shell 不会自动加载 `.env`，运行前需要显式 `source` 或由部署系统注入环境变量。示例输出会把 bearer token 脱敏。

默认命令只验证图装配和本地生命周期，不会让确定性模型调用异步工具，也不声称远程调用已经发生。该能力仍为 preview；升级版本后先运行契约测试，再运行远程集成测试。
