#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -x "$ROOT/.venv/bin/python" ]]; then
  export PYTHON_BIN="$ROOT/.venv/bin/python"
else
  export PYTHON_BIN="${PYTHON_BIN:-python3}"
fi

for case_dir in "$ROOT"/p[0-9][0-9]_*; do
  echo "==> $(basename "$case_dir")"
  (cd "$case_dir" && ./test.sh)
done

echo "==> course_reference_app"
(cd "$ROOT/course_reference_app" && ./test.sh)

echo "==> regression tests"
"$PYTHON_BIN" -m unittest discover -s "$ROOT/tests" -p "test_*.py" -v

echo "All Harness examples passed."
