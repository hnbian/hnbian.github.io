from __future__ import annotations

import argparse
import asyncio
import os
from typing import Any, cast

import httpx
import uvicorn
from api.routes import router
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport
from mcp_server.server import mcp

ROOT = os.path.dirname(__file__)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def create_app() -> FastAPI:
    mcp_asgi = mcp.http_app(path="/")
    api = FastAPI(
        title="Harness Course Reference App",
        lifespan=mcp_asgi.lifespan,
    )
    api.include_router(router, prefix="/api")
    api.mount("/mcp", mcp_asgi)

    @api.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        return FileResponse(os.path.join(ROOT, "frontend", "index.html"))

    return api


app = create_app()


async def self_test() -> None:
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        health = await client.get("/api/health")
        require(health.json() == {"status": "ok"}, "health endpoint failed")

        plan = await client.post("/api/procurement/plan", json={"sku": "M8-BOLT", "required": 500})
        require(plan.status_code == 200, f"plan failed: {plan.text}")
        require(plan.json()["shortage"] == 260, "incorrect shortage")
        blank_sku = await client.post(
            "/api/procurement/plan",
            json={"sku": "   ", "required": 1},
        )
        require(blank_sku.status_code == 422, "blank SKU was accepted")
        boolean_required = await client.post(
            "/api/procurement/plan",
            json={"sku": "M8-BOLT", "required": True},
        )
        require(boolean_required.status_code == 422, "boolean demand was accepted")

        events = await client.get("/api/events/demo")
        require("event: status" in events.text, "SSE status event missing")

    def client_factory(**kwargs: Any) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://test",
            **kwargs,
        )

    mcp_transport = StreamableHttpTransport(
        "http://test/mcp/",
        # FastMCP 3.4.4 passes follow_redirects although the upstream MCP
        # callable protocol has not yet declared that keyword.
        httpx_client_factory=cast(Any, client_factory),
    )
    async with app.router.lifespan_context(app), Client(mcp_transport) as mcp_client:
        tools = await mcp_client.list_tools()
        require(
            any(tool.name == "get_inventory" for tool in tools),
            "MCP inventory tool missing",
        )
        result = await mcp_client.call_tool("get_inventory", {"sku": "M8-BOLT"})
        require("240" in str(result), "MCP inventory result incorrect")

    print("course reference app self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        asyncio.run(self_test())
        return
    if args.serve:
        uvicorn.run(
            "app:app",
            host=os.getenv("APP_HOST", "127.0.0.1"),
            port=int(os.getenv("APP_PORT", "8000")),
            reload=False,
        )
        return
    print("Use --self-test or --serve")


if __name__ == "__main__":
    main()
