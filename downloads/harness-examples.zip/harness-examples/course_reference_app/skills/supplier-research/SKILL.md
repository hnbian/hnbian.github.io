---
name: supplier-research
description: Compare qualified supplier quotes when a procurement shortage exists.
---

# Supplier research

1. Do not research suppliers when the shortage is zero.
2. Reject non-positive prices and unqualified suppliers.
3. Return the selected quote with source and decision reason.
