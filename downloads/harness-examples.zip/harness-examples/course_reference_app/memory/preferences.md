# Procurement preferences

- Minimum payment term: 30 days.
- Require human approval when the configured threshold is reached.
