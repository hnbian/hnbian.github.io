#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -c 'import sys; raise SystemExit(sys.version_info < (3, 11))'
"$PYTHON_BIN" app.py --self-test
