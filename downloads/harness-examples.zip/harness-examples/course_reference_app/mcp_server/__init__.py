"""MCP server package."""
