from agent.workflow import INVENTORY
from fastmcp import FastMCP

mcp = FastMCP("Harness ERP Gateway")


@mcp.tool
def get_inventory(sku: str) -> dict[str, int | str]:
    """Return the deterministic inventory fixture for one SKU."""
    return {"sku": sku, "available": INVENTORY.get(sku, 0)}
