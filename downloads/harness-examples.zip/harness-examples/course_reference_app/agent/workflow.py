from __future__ import annotations

from typing import TypedDict


class ProcurementPlan(TypedDict):
    sku: str
    required: int
    inventory: int
    shortage: int
    status: str


INVENTORY = {"M8-BOLT": 240}


def build_procurement_plan(sku: str, required: int) -> ProcurementPlan:
    if not isinstance(sku, str) or not sku.strip():
        raise ValueError("sku is required")
    if isinstance(required, bool) or not isinstance(required, int) or required < 0:
        raise ValueError("required must be non-negative")
    inventory = INVENTORY.get(sku, 0)
    shortage = max(required - inventory, 0)
    return {
        "sku": sku,
        "required": required,
        "inventory": inventory,
        "shortage": shortage,
        "status": "supplier_research" if shortage else "completed_no_purchase",
    }
