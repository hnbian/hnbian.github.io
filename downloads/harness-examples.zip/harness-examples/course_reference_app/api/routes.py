from __future__ import annotations

import json
from collections.abc import AsyncIterator

from agent.workflow import ProcurementPlan, build_procurement_plan
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

router = APIRouter()


class ProcurementRequest(BaseModel):
    sku: str = Field(min_length=1, pattern=r"^.*\S.*$", strict=True)
    required: int = Field(ge=0, strict=True)


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/procurement/plan")
async def plan(request: ProcurementRequest) -> ProcurementPlan:
    try:
        return build_procurement_plan(request.sku, request.required)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/events/{run_id}")
async def events(run_id: str) -> StreamingResponse:
    async def stream() -> AsyncIterator[str]:
        payload = json.dumps({"run_id": run_id, "status": "ready"})
        yield f"id: 1\nevent: status\ndata: {payload}\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")
