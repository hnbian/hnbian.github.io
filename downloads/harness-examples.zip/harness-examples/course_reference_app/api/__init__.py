"""FastAPI routes package."""
