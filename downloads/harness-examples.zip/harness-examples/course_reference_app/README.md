# Course Reference App

## 功能

这是根据课程第 2、3、11 节字幕中可见职责重建的整合应用，不是缺失课程源码的逐文件复制。它把此前分散示例中的可运行边界组合到一个项目结构中：

```text
course_reference_app/
├── agent/          # 确定性采购业务工作流
├── api/            # FastAPI REST 与 SSE 路由
├── downloads/      # 报告下载边界说明
├── frontend/       # 最小原生 Web 消费端（课程原项目使用 Vue）
├── mcp_server/     # FastMCP 库存工具
├── memory/         # 示例长期指令文件
├── skills/         # 示例 SKILL.md
├── app.py          # 组合 API 与 MCP transport
└── test.sh
```

## 环境要求

- Python 3.11+（项目验收使用 Python 3.12）
- 默认不需要模型、ERP、OpenSandbox 或其他远程服务
- 手工服务验证需要本机端口 `8000` 可用

## 安装与运行

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
PYTHON_BIN=.venv/bin/python ./test.sh
.venv/bin/python app.py --serve
```

打开 `http://127.0.0.1:8000/` 查看前端，REST 健康检查位于 `/api/health`，MCP HTTP transport 位于 `/mcp/`。

## 示例输出

```text
course reference app self-test passed
```

父 FastAPI 接管 FastMCP HTTP 应用的 lifespan。默认测试显式启动该生命周期，通过进程内 ASGI 验证健康检查、采购计划和 SSE，并让 FastMCP Client 通过实际挂载的 `/mcp/` Streamable HTTP transport 调用 `get_inventory`，不依赖在线模型、ERP 或 OpenSandbox。生产环境应替换确定性库存和供应商夹具，并增加认证、持久存储与真实沙箱。
