# Harness Course Code

本目录对应博客仓库 `source/_posts/harness/docs/` 下的 Harness 系列。所有案例都提供无 API 密钥的确定性运行路径；涉及真实模型、OpenSandbox 或远程 Agent Server 的部分必须显式启用。

## 环境

- Python 3.11+（本机验证：Python 3.12）
- macOS/Linux shell
- 可选：OpenAI 兼容模型密钥、OpenSandbox Server、Docker/Kubernetes

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

## 代码地图

| 目录 | 能力 | 默认是否需要外部服务 |
|---|---|---|
| `p01_harness_concepts` | 安全的最小 Agent 工具循环 | 否 |
| `p02_agent_loop` | 分层运行时、中间件与有界瞬态重试 | 否 |
| `p03_deepagents_quickstart` | 真实 Deep Agents 图与工具调用 | 否；live 模式需要模型 |
| `p04_planning_filesystem` | 真实 `write_todos`、文件工具与 CompositeBackend | 否 |
| `p05_multi_agent` | 真实 Deep Agents `task` 子代理与委派契约 | 否 |
| `p06_context_memory_skills` | Skills 渐进加载与 StoreBackend 跨线程记忆 | 否 |
| `p07_sandbox_hitl` | LangGraph interrupt 与 OpenSandbox 配置 | 否；创建沙箱需要 Server |
| `p08_fastapi_sse_mcp` | FastAPI、可恢复 SSE、幂等审批与 MCP HTTP transport | 否 |
| `p09_async_subagents` | 真实五工具图装配与可更新/取消的本地生命周期 | 否；远程执行需要 Agent Server |
| `p10_procurement_harness` | LangGraph 采购工作流、检查点、HITL 与报告 | 否 |
| `course_reference_app` | 按字幕第 11 节职责重建的 API、Agent、MCP、前端、skills、memory 整合骨架 | 否 |

## 一键安装与验证

每个目录都可以独立执行：

```bash
cd p03_deepagents_quickstart
../.venv/bin/pip install -r requirements.txt
PATH="../.venv/bin:$PATH" ./test.sh
../.venv/bin/python main.py
```

验证全部案例：

```bash
./test_all.sh
```

安装并运行静态质量门禁：

```bash
.venv/bin/pip install -r requirements-dev.txt
PYTHON_BIN=.venv/bin/python ./test_quality.sh
```

`test_all.sh` 不访问网络、不读取真实密钥，也不会连接生产 ERP。外部基础设施的验收命令记录在相应目录的 README 中。

`tests/test_regressions.py` 额外覆盖幂等请求指纹、SSE 事件顺序、异步更新/取消、无采购缺口、非法需求和重复 run id。自测使用显式异常断言，即使启用 `python -O` 也不会被移除。

`course_reference_app` 是根据字幕可见职责重建的可运行参考应用，不是课程缺失源码的逐文件复制；它由总测试额外验证。

## 固定版本

系列在 2026-07-27 使用稳定版验证：

- `deepagents==0.6.12`
- `langchain==1.3.14`
- `langgraph==1.2.9`
- `langchain-openai==1.4.1`
- `fastapi==0.140.0`
- `fastmcp==3.4.4`
- `opensandbox==0.1.15`
- `uvicorn==0.51.0`

异步子代理仍是预览能力；升级 Deep Agents 时应先运行第 9 个案例的契约测试。

官方网页会持续更新，而代码固定在上述稳定版本。涉及 API 字段和工具名的结论以固定版本的运行时反射测试为准；升级前不要只根据无版本网页判断兼容性。
